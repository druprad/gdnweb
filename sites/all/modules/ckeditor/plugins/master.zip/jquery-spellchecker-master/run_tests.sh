echo -e "\n"Running Javascript tests..."\n"

grunt jasmine

echo -e "\n"Running PHP tests..."\n"

./vendor/bin/phpunit tests/php